﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PrimS.Telnet;

namespace Poc
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("LazyBone Proof-Of-Concept");
                Console.WriteLine("-------------------------");
                Console.WriteLine();

                using (Client client = new Client("10.0.1.127", 2000, new System.Threading.CancellationToken()))
                {
                    if (client.IsConnected)
                    {
                        Console.WriteLine("[INFO] Connected to the LazyBone!");
                        Console.WriteLine();
                    }

                    Console.WriteLine("List of possible commands:");
                    Console.WriteLine("Set to position 1 = 'e'");
                    Console.WriteLine("Set to position 0 = 'o'");
                    Console.WriteLine();
                    Console.WriteLine("Provide a command and press ENTER:");

                    while (true)
                    {
                        string cmd = Console.ReadLine();
                        client.Write(cmd).Wait();
                        Console.WriteLine(client.ReadAsync().Result);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Something went horribly wrong!");
                Console.WriteLine("Press any key to exit...");
                Console.ReadLine();
            }
        }
    }
}
